# KMIA VATSIM Landing Cam — OBS Overlay

A red aviation-broadcast-style, browser-based overlay for a Microsoft Flight Simulator spectator camera at KMIA. It reads the public VATSIM network feed, shows pilots with KMIA filed as their destination within 150 NM, and supports manual landing ratings.

## Features

- Live VATSIM arrival list (refreshes every ~15 seconds)
- Callsign, filed aircraft type, origin, altitude, groundspeed and approximate distance from KMIA
- Select an arrival from the queue
- KMIA METAR via AviationWeather.gov, where browser/network access allows
- Best-effort KMIA ATIS controller presence check
- Manual landing rating: callsign, score, optional FPM entry and comment
- Transparent background designed for OBS Browser Source

## Important limitations

- VATSIM's public traffic feed does **not** provide touchdown FPM or a landing score. FPM is optional and entered manually.
- Arrivals are selected by filed destination KMIA and distance <= 150 NM. This does not prove the aircraft is on final approach; use the distance/status as an aid, not a definitive approach detector.
- The public VATSIM feed is refreshed approximately every 15 seconds. Feed or browser CORS restrictions may affect client-side fetching.
- ATIS display checks for a controller callsign beginning with `KMIA_ATIS`; it does not retrieve spoken ATIS audio or guarantee ATIS text.
- Manual ratings are stored in that browser's localStorage. On a hosted site, each viewer/browser has separate ratings; this is not a shared multi-user database.
- Airport/weather feeds and third-party API behavior may change. The app displays unavailable status rather than inventing data.

## Run locally first

Requires Node.js 18+.

1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000` to test.

## Add to OBS

1. Open OBS and select your KMIA landing-cam scene.
2. Under **Sources**, click **+ → Browser**.
3. Name it `KMIA VATSIM Overlay`.
4. For local testing, set URL to `http://localhost:3000`.
5. Set width `1920`, height `1080`.
6. Ensure **Shutdown source when not visible** is disabled if you want it to keep refreshing while hidden.
7. Position/resize the Browser Source to cover the canvas. Its page background is transparent.
8. Keep the MSFS camera capture below the Browser Source in the source list.

The rating controls are interactive in the OBS browser source. For convenient testing, open the overlay URL in a normal browser too.

## Deploy as a hosted webpage

This project is a standard Node/Express web app. Deploy it to a Node-compatible host that supports running `npm start` and sets the `PORT` environment variable. For example, create a new web service from the extracted Git repository and configure:

- Build/install command: `npm install`
- Start command: `npm start`
- Node version: 18 or newer

The hosted provider should serve the `public` directory through `server.js`. After deployment, use the provider's HTTPS URL in OBS Browser Source.

Do not publish private API keys in `public/app.js`. This app currently uses public data endpoints only.

## How to use manual ratings

1. Select a flight from the arrival queue or the Flight dropdown.
2. After observing the landing, enter FPM if you have a reliable measurement; otherwise leave it blank.
3. Select a score and optionally add a comment.
4. Click **PUBLISH RATING**.

The score and optional FPM are manual inputs, not automatic VATSIM measurements.

## Files

- `server.js` — simple static web server
- `public/index.html` — overlay layout and controls
- `public/style.css` — visual theme
- `public/app.js` — VATSIM traffic, weather, ATIS best-effort check, manual ratings
- `package.json` — Node dependencies
